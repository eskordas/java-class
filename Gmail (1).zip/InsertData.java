import java.util.*;

public class InsertData {
        public static ArrayList<Data> addData(ArrayList<Data> info){
                int id;
                Scanner input = new Scanner(System.in);
                String answer="";
                System.out.println("Insert the Id number of the new info");
                try{
                        id = input.nextInt();
                }
                catch (Exception e){
                        System.out.println("Wrong input. Id number is an integer number");
                        System.out.println("Now you will return to the main menu.");
                        return info;
                }
                
                answer = input.nextLine();
                for(Data x:info){
                        if(x.getId()==id){
                                System.out.println("This Id number already exists");
                                System.out.println("Would you like to remove the existing one and recreate it?");
                                System.out.println("If you do insert -yes-. ");
                                System.out.println("Any other answer will forward you to the main menu with the database unchanged.");
                                answer = input.nextLine();
                              
                                if(answer.equalsIgnoreCase("yes")){
                                        RemoveData.deleteData(id,info);
                                        break;
                                }
                                else{
                                        System.out.println("-Return to main menu-"); 
                                        return info;
                                }
                        }
                }
                Data data=new Data(id);
                
                System.out.println("Insert information about this product");
                answer = input.nextLine();
                
                data.insertInfo(answer); 
                while(true){
                        
                        
                        System.out.println("Do you want to add more information about this product?");
                        System.out.println("If you do insert -yes-. ");
                        answer = input.nextLine();
                        if(answer.equalsIgnoreCase("yes")){
                                System.out.println("Insert information about this product");
                                answer = input.nextLine();    
                                data.insertInfo(answer);
                        }else
                        {
                                System.out.println("-Return to main menu-");
                                break;
                        }
                }
                info.add(data);
                Collections.sort(info, new Comparator<Data>(){
                        @Override
                        public int compare(Data data1, Data data2)
                        {
                                
                                return  Integer.valueOf(data1.getId()).compareTo(data2.getId());
                        }
                });
                
                return info;
                
        }
}
