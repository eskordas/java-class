import java.util.*;

public class Data {
        private int id;
        private ArrayList<String> info=new ArrayList<String>();
        public Data(int id){
                this.id=id;
        }
        public  void insertInfo(String newInfo){
                this.info.add(newInfo);
        }
        public  ArrayList<String> getInfo(){
                return this.info;
        }
        public int getId(){
                return this.id;
        }
        
        
}
